// `npx cap add android` ke BAAD ek baar chalao:  node setup-android.js
// Ye AndroidManifest.xml me AdMob App ID apne aap daal deta hai (www/ads-config.js se padhta hai).
const fs=require('fs');
const cfg=fs.readFileSync('www/ads-config.js','utf8');
const m=cfg.match(/APP_ID:\s*'([^']+)'/);
if(!m){console.error('APP_ID www/ads-config.js me nahi mila');process.exit(1)}
const f='android/app/src/main/AndroidManifest.xml';
if(!fs.existsSync(f)){console.error('Pehle `npx cap add android` chalao');process.exit(1)}
let x=fs.readFileSync(f,'utf8');
if(x.includes('com.google.android.gms.ads.APPLICATION_ID')){console.log('Pehle se jura hua hai, kuch nahi badla');process.exit(0)}
x=x.replace(/<application([^>]*)>/,(a)=>a+'\n        <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="'+m[1]+'"/>');
fs.writeFileSync(f,x);console.log('AdMob App ID manifest me jod diya:',m[1]);
