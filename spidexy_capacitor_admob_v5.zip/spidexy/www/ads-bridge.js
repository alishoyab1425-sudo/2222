// Game ke Ads manager ko asli AdMob se jodta hai (Capacitor AdMob plugin).
// Agar plugin nahi mila (browser me), game apne practice ads dikhata hai.
(function(){
 var C=window.ADS_CONFIG||{};
 function plug(){return window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.AdMob}
 var ready=false,initing=null;
 function init(){var A=plug();if(!A)return Promise.reject();if(ready)return Promise.resolve();if(initing)return initing;
  initing=A.initialize({initializeForTesting:!!C.TESTING,tagForChildDirectedTreatment:true,tagForUnderAgeOfConsent:true,maxAdContentRating:'G'}).then(function(){ready=true}).catch(function(e){initing=null;throw e});return initing}
 function once(A,ev,fn){var h=null,done=false;A.addListener(ev,function(x){if(done)return;done=true;try{h&&h.remove&&h.remove()}catch(e){}fn(x)}).then(function(r){h=r});}
 window.SpiderrunAds={
  showRewarded:function(cb){var A=plug();if(!A){cb(false);return}var got=false,fin=false;function end(ok){if(fin)return;fin=true;cb(ok)}
   init().then(function(){
    once(A,'onRewardedVideoAdReward',function(){got=true});
    once(A,'onRewardedVideoAdDismissed',function(){end(got)});
    once(A,'onRewardedVideoAdFailedToShow',function(){end(false)});
    return A.prepareRewardVideoAd({adId:C.REWARDED,isTesting:!!C.TESTING}).then(function(){return A.showRewardVideoAd()});
   }).catch(function(){end(false)});
   setTimeout(function(){end(got)},120000)},
  showInterstitial:function(cb){var A=plug();if(!A){cb();return}var fin=false;function end(){if(fin)return;fin=true;cb()}
   init().then(function(){
    once(A,'onInterstitialAdDismissed',end);once(A,'onInterstitialAdFailedToShow',end);
    return A.prepareInterstitial({adId:C.INTERSTITIAL,isTesting:!!C.TESTING}).then(function(){return A.showInterstitial()});
   }).catch(end);setTimeout(end,30000)},
  showBanner:function(){var A=plug();if(!A)return;init().then(function(){return A.showBanner({adId:C.BANNER,adSize:'ADAPTIVE_BANNER',position:'BOTTOM_CENTER',margin:0,isTesting:!!C.TESTING})}).catch(function(){})},
  hideBanner:function(){var A=plug();if(!A)return;try{A.removeBanner()}catch(e){}}
 };
})();
