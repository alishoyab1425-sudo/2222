// ===== AdMob IDs (S.K Studios / Spidexy) - sab asli IDs =====
// TESTING:false = asli ads (release ke liye). Phone par khud test karna ho to true karo,
// warna apne hi ads par click karne se AdMob account band ho sakta hai.
window.ADS_CONFIG={
  TESTING:false,
  APP_ID:'ca-app-pub-1466673767880620~4351664074',
  INTERSTITIAL:'ca-app-pub-1466673767880620/9791819327',
  REWARDED:'ca-app-pub-1466673767880620/7994240663',
  BANNER:'ca-app-pub-1466673767880620/6493456730'
};
